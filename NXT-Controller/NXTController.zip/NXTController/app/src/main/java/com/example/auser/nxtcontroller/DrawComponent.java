package com.example.auser.nxtcontroller;

import android.graphics.Canvas;

public abstract class DrawComponent {

    public void regularDraw (Canvas canvas){}

}
