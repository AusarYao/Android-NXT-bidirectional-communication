package com.example.auser.nxtcontroller;

public class PointF {
    public float x, y;
    public PointF(float inX, float inY){
        x = inX;
        y = inY;

    }

}
