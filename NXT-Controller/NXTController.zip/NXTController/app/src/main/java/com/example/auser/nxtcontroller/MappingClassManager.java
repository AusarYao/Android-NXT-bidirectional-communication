package com.example.auser.nxtcontroller;

/*
*
* This class is not finished. It should be used to do all the initialization work of DrawComponent
* class so that AutoMappingView has a simpler function
*
*/

public class MappingClassManager {
}
